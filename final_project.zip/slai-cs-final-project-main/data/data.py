import sqlite3
import pandas as pd


#file name
connection = sqlite3.connect('demo.db')


df = pd.read_csv('data/csv/College-labor-data.csv')


df.columns = df.columns.str.strip()



df.to_sql("data_2", connection, if_exists='replace', index=False)